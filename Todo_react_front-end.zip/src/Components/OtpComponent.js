import React, { useState } from "react";
import PinInput from "react-pin-input";
import NewPassword from "./NewPassword"; // Adjust the import path as needed

function ValidateOtp({ email }) {
  const [otpCompleted, setOtpCompleted] = useState(false);

  const handleComplete = (value) => {
    console.log("Entered PIN:", value);
    setOtpCompleted(true); // Update state to show NewPassword component
  };

  return (
  <div>
     {!otpCompleted ? (
      <div className="flex justify-center items-center mt-2">
        <div className="w-96 border rounded bg-white py-10 p-17 ">
            <h4 className="text-2xl mb-7 ml-14 pl-8">Validate OTP</h4>
            <PinInput
              length={4}
              type="numeric"
              onChange={(value) => console.log("PIN Changed:", value)}
              onComplete={handleComplete}
              inputMode="numeric"
              style={{ marginBottom: "1rem", marginLeft: "1rem" }}
            />
        
        </div>
      </div>): <NewPassword/>}
      </div>
   
  );
}

export default ValidateOtp;
