import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import PasswordInput from "../Components/PasswordInput";
import { validateEmail } from "../Utilis/helper";
import axiosInstance from "../Utilis/axiosInstance";

function NewPassword() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [password1, setPassword1] = useState("");
  const [error, setError] = useState("");
  const navigate = useNavigate();

  const handlelogin = async (e) => {
    e.preventDefault();
    if (!password) {
      setError("please enter a valid password");
      return;
    } else {
      setError("");
    }

    if (password.length < 8) {
      setError("please enter atLeast 8 digit password");
      return;
    } else {
      setError("");
    }

    if (password !== password1) {
      setError("Password not matched");
      return;
    } else {
      setError("");
    }

    //API  call for my future code

    // try {
    //   const content = {
    //     email: email,
    //     password: password,
    //   };
    //   const response = await axiosInstance.post("/auth/login", content, {});

    //   //handle successful login response
    //   if (response.data && response.data.accessToken) {
    //     localStorage.setItem("token", response.data.accessToken);
    //     navigate("/");
    //   }
    // } catch (error) {
    //   if (
    //     error.response &&
    //     error.response.data &&
    //     error.response.data.message
    //   ) {
    //     setError(error.response.data.message);
    //   } else {
    //     setError("unexpected error");
    //   }
    // }
  };

  return (
    <div>
      <form onSubmit={handlelogin}>
        <h4 className="text-2xl mb-7">Enter Password</h4>
        <PasswordInput
          value={password}
          onChange={(e) => setPassword(e.target.value)}
        ></PasswordInput>
        <PasswordInput
          value={password1}
          onChange={(e) => setPassword1(e.target.value)}
          placeholder={"Confirm Password"}
        ></PasswordInput>
        {error && <p className="text-red-500  text-xs pb-1 mt-3">{error}</p>}
        <button type="submit" className="btn-primary">
          Submit
        </button>
      </form>
    </div>
  );
}

export default NewPassword;
