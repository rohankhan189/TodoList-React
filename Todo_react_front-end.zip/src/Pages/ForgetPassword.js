import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { validateEmail } from "../Utilis/helper";
import axiosInstance from "../Utilis/axiosInstance";
import ValidateOtp from "../Components/OtpComponent";

function ForgetPass() {
  const [email, setEmail] = useState("");
  const [showOtpInput, setShowOtpInput] = useState(false);
  const [error, setError] = useState("");
  const navigate = useNavigate();

  const handleEmailSubmit = async (e) => {
    e.preventDefault();
    if (!validateEmail(email)) {
      setError("Enter a valid email");
      return;
    }
    setError("");

    try {
      setShowOtpInput(true);
      // Simulate an API call to send OTP
      //   const response = await axiosInstance.post("/auth/forgot-password", { email });

      //   if (response.data.success) {
      //     // Show the OTP input field
      //   } else {
      //     setError("Failed to send OTP. Please try again.");
      //   }
    } catch (error) {
      setError("An unexpected error occurred. Please try again.");
    }
  };

  return (
    <div className="flex justify-center items-center mt-28">
      <div className="w-96 border rounded bg-white px-7 py-10">
        {!showOtpInput ? (
          <form onSubmit={handleEmailSubmit}>
            <h4 className="text-2xl mb-7">Enter Email</h4>
            <input
              type="email"
              placeholder="Email"
              className="input-box"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
            ></input>
            {error && <p className="text-red-500 text-xs pb-1 mt-3">{error}</p>}
            <button type="submit" className="btn-primary">
              Send
            </button>
          </form>
        ) : (
          <ValidateOtp email={email} /> // Render the ValidateOtp component when OTP is sent
        )}
      </div>
    </div>
  );
}

export default ForgetPass;
